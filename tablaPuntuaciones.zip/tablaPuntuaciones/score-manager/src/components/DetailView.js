import React from 'react'

export default function DetailView({scoreData}) {
  return (     
    <div>
        <h1>Team {scoreData[0].team}</h1>
        <h1></h1>
        <hr></hr>        
    </div>
    
  )
}


